# Retro Chat — Android starter project

Retro Chat is a dark, purple-and-blue social app starter built with Kotlin and Jetpack Compose.

## Included
- Splash/brand header and bottom navigation
- Home social feed with sample posts and reactions
- Reels-style vertical video discovery screen (demo cards; no actual video playback yet)
- Friends/community screen
- Inbox screen (demo conversations)
- Creator profile screen
- Settings entry point
- Firebase setup notes and suggested backend architecture

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK 35

## Open and run
1. Unzip the project.
2. Open the `RetroChatAndroid` folder in Android Studio.
3. Allow Gradle sync.
4. Run on an emulator or Android phone.

This is a starter/MVP UI project, not a finished production social network. Sample content is local and demo-only. Authentication, media uploads, live messaging, calling, notifications, moderation, and server rules must be implemented and tested before public launch.

## Add Firebase
1. Create a project in Firebase Console and register an Android app with package `com.retrochat`.
2. Download `google-services.json` and place it in `app/`.
3. Add the Google Services Gradle plugin and Firebase BoM dependencies as described in Firebase's current Android documentation.
4. Implement Firebase Authentication, Cloud Firestore, Cloud Storage, and Firebase Cloud Messaging.
5. Configure Firestore and Storage security rules before uploading any real user data.

## Suggested Firestore collections
- `users/{uid}`: displayName, username, photoURL, bio, createdAt
- `posts/{postId}`: authorId, text, mediaURLs, createdAt, visibility
- `posts/{postId}/likes/{uid}`
- `posts/{postId}/comments/{commentId}`
- `conversations/{conversationId}`: memberIds, updatedAt
- `conversations/{conversationId}/messages/{messageId}`: senderId, text, mediaURL, createdAt
- `groups/{groupId}` and `groups/{groupId}/members/{uid}`
- `reports/{reportId}` and `blocks/{uid}/users/{blockedUid}`

## Production checklist
- Secure authentication and account recovery
- Server-enforced authorization and rate limits
- Upload size/type validation and media transcoding
- Report/block tools, moderation queue, community guidelines
- Privacy policy, terms, account deletion and data export
- Push notifications, analytics consent, crash reporting
- Accessibility, localization, device testing and Play Console compliance
