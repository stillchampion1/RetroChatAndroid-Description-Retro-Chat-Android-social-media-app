# Build Retro Chat from an Android phone (free route)

This project includes a GitHub Actions workflow that attempts to build a debug APK in the cloud. It does not require a payment card to run the workflow on a public GitHub repository, subject to GitHub's current policies and limits.

## Steps
1. In your phone browser, sign in to GitHub with your Gmail address (or create a GitHub account).
2. Create a **public** repository named `RetroChatAndroid` (public keeps the workflow within GitHub's free usage policy more likely; review GitHub's current limits before use).
3. Upload the contents of this ZIP into the repository. Upload the files and folders inside `RetroChatAndroid`, not the outer folder itself. Ensure `.github/workflows/android-apk.yml` is included. Some mobile upload screens hide dot-folders; if `.github` cannot be uploaded from the browser, the workflow cannot run until that folder is uploaded using GitHub's web interface or another file-upload method.
4. Open the repository's **Actions** tab, choose **Build Retro Chat APK**, and tap **Run workflow**. If asked, enable Actions for the repository.
5. When the workflow finishes successfully, open that workflow run and download the `RetroChat-debug-apk` artifact. Extract the ZIP to get `app-debug.apk`.
6. Tap the APK on your phone to install it. Android may ask you to allow installation from that browser or file manager; only enable this for the app you trust, then turn it off again afterwards.

## Important limitations
- This is a debug APK for testing, not a signed production release.
- The current app is a UI starter with sample/local content. The cloud workflow only compiles it; it does not add real accounts, online posts, video hosting, or live messaging.
- The workflow has not yet been verified by a successful cloud run. If it fails, use the Actions log to identify and fix the issue.
- Never commit passwords, API keys, signing keys, or private user data to a public repository.
