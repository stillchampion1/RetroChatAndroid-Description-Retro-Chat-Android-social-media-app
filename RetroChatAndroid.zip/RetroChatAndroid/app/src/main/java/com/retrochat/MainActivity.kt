package com.retrochat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF080A18)
private val Panel = Color(0xFF12162B)
private val Purple = Color(0xFFB44CFF)
private val Blue = Color(0xFF32B9FF)
private val Muted = Color(0xFFAAB2D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RetroChatApp() }
    }
}

private enum class Tab(val label: String) {
    Home("Home"), Reels("Reels"), Friends("Friends"), Inbox("Inbox"), Profile("Profile")
}

@Composable
private fun RetroChatApp() {
    var selected by remember { mutableStateOf(Tab.Home) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            secondary = Blue,
            background = Night,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0E1123), contentColor = Color.White) {
                    Tab.values().forEach { tab ->
                        val icon = when (tab) {
                            Tab.Home -> Icons.Default.Home
                            Tab.Reels -> Icons.Default.PlayCircle
                            Tab.Friends -> Icons.Default.People
                            Tab.Inbox -> Icons.Default.Chat
                            Tab.Profile -> Icons.Default.Person
                        }
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Icon(icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Blue,
                                selectedTextColor = Blue,
                                indicatorColor = Color(0xFF282044),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    Tab.Home -> HomeScreen()
                    Tab.Reels -> ReelsScreen()
                    Tab.Friends -> FriendsScreen()
                    Tab.Inbox -> InboxScreen()
                    Tab.Profile -> ProfileScreen()
                }
            }
        }
    }
}

@Composable
private fun BrandHeader(subtitle: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(Purple, Blue))),
            contentAlignment = Alignment.Center
        ) {
            Text("R▶", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Retro Chat", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "Notifications", tint = Blue) }
        IconButton(onClick = {}) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
    }
}

@Composable
private fun HomeScreen() {
    var postText by remember { mutableStateOf("") }
    var showComposer by remember { mutableStateOf(false) }
    var likedPosts by remember { mutableStateOf(setOf<Int>()) }
    val posts = listOf(
        DemoPost(1, "Saviour Agbosu", "God's plan is always the best plan 🙏", "Music • Worship • Lifestyle", "2h", "248", "45"),
        DemoPost(2, "Ama Serwaa", "A little reminder to keep shining ✨", "Community", "4h", "126", "18"),
        DemoPost(3, "Kojo Mensah", "Weekend moments with my people 🌅", "Friends", "6h", "89", "12")
    )
    Column(Modifier.fillMaxSize()) {
        BrandHeader("Connect • Share • Watch • Chat")
        LazyColumn(contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf("Your Story", "Maria", "James", "Abena").forEachIndexed { i, name ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(66.dp)) {
                            Box(Modifier.size(54.dp).clip(CircleShape).background(
                                Brush.linearGradient(listOf(if (i % 2 == 0) Purple else Blue, Color(0xFF272B54)))
                            ), contentAlignment = Alignment.Center) {
                                Text(if (i == 0) "+" else name.take(1), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                            Text(name, color = Muted, fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(18.dp))
                        .background(Panel).clickable { showComposer = !showComposer }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar("R", Purple)
                    Spacer(Modifier.width(10.dp))
                    Text("What's on your mind?", color = Muted, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.AddCircle, null, tint = Blue)
                }
                if (showComposer) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(Panel).padding(12.dp)) {
                        OutlinedTextField(value = postText, onValueChange = { postText = it }, label = { Text("Write a post") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { postText = ""; showComposer = false }, modifier = Modifier.align(Alignment.End)) { Text("Post demo") }
                        Text("Demo only: posts are not uploaded to a server yet.", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            items(posts) { post ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).clip(RoundedCornerShape(20.dp)).background(Panel).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(post.author.take(1), if (post.id % 2 == 0) Blue else Purple)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(post.author, fontWeight = FontWeight.Bold)
                            Text("${post.time} · ${post.category}", color = Muted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.MoreHoriz, null, tint = Muted)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(post.message, fontSize = 15.sp)
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(14.dp)).background(
                        Brush.linearGradient(listOf(Color(0xFF1C2A56), Color(0xFF3C1B55), Color(0xFF112B42)))
                    ), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Blue, modifier = Modifier.size(32.dp))
                            Text("Retro moments", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Photo or video preview", color = Muted, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("${post.likes} reactions     ${post.comments} comments", color = Muted, fontSize = 12.sp)
                    Divider(Modifier.padding(vertical = 8.dp), color = Color(0xFF2B304A))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        TextButton(onClick = { likedPosts = if (post.id in likedPosts) likedPosts - post.id else likedPosts + post.id }) {
                            Icon(Icons.Default.Favorite, null, tint = if (post.id in likedPosts) Purple else Muted)
                            Spacer(Modifier.width(5.dp)); Text(if (post.id in likedPosts) "Liked" else "Like")
                        }
                        TextButton(onClick = {}) { Icon(Icons.Default.ChatBubbleOutline, null); Spacer(Modifier.width(5.dp)); Text("Comment") }
                        TextButton(onClick = {}) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(5.dp)); Text("Share") }
                    }
                }
            }
        }
    }
}

private data class DemoPost(val id: Int, val author: String, val message: String, val category: String, val time: String, val likes: String, val comments: String)

@Composable
private fun Avatar(letter: String, color: Color) {
    Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(color, Blue))), contentAlignment = Alignment.Center) {
        Text(letter, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
private fun ReelsScreen() {
    var current by remember { mutableIntStateOf(0) }
    val creators = listOf("@beauty_ghana", "@retro_creator", "@musicwithama")
    val captions = listOf("Good vibes only ✨ Keep your light shining.", "A moment worth sharing with the Retro community.", "New sounds, new stories, one community.")
    Box(Modifier.fillMaxSize().padding(12.dp).clip(RoundedCornerShape(24.dp)).background(
        Brush.linearGradient(listOf(Color(0xFF17264B), Color(0xFF35174B), Color(0xFF080A18)))
    )) {
        Column(Modifier.align(Alignment.TopStart).padding(18.dp)) {
            Text("Retro Reels", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("Following     For You", color = Muted)
        }
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.PlayCircle, null, tint = Blue, modifier = Modifier.size(76.dp))
            Text("Short video preview", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Connect with creators and discover trends", color = Muted)
            Spacer(Modifier.height(18.dp))
            Button(onClick = { current = (current + 1) % creators.size }) { Text("Next demo video") }
            Text(creators[current], color = Blue, fontWeight = FontWeight.Bold)
            Text(captions[current], color = Color.White)
        }
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = {}) { Icon(Icons.Default.Favorite, null, tint = Color.White) }
            Text("12.4K", color = Color.White, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            IconButton(onClick = {}) { Icon(Icons.Default.ChatBubbleOutline, null, tint = Color.White) }
            Text("342", color = Color.White, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            IconButton(onClick = {}) { Icon(Icons.Default.Share, null, tint = Color.White) }
            Text("Share", color = Color.White, fontSize = 11.sp)
        }
        Text("Demo content — connect a video backend for real playback.", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(16.dp))
    }
}

@Composable
private fun FriendsScreen() {
    val people = listOf("Ama Serwaa", "Kojo Mensah", "Maria Owusu", "James Boateng", "Abena K.")
    Column(Modifier.fillMaxSize()) {
        BrandHeader("Friends & communities")
        Text("People you may know", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(people) { person ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(person.take(1), Purple)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(person, fontWeight = FontWeight.SemiBold)
                        Text("Retro Chat member", color = Muted, fontSize = 12.sp)
                    }
                    Button(onClick = {}, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) { Text("Add") }
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text("Communities", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                listOf("Gospel Music & Worship", "Accra Creators", "Photography & Travel").forEach {
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Groups, null, tint = Blue)
                        Spacer(Modifier.width(12.dp)); Text(it, Modifier.weight(1f))
                        Text("Join", color = Purple, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun InboxScreen() {
    val chats = listOf(
        Triple("Maria Owusu", "That sounds great! Catch up this weekend.", "10:25 AM"),
        Triple("Ama Serwaa", "Sent you a voice message", "Yesterday"),
        Triple("Retro Creators", "Kojo: New video is up 🎬", "Yesterday"),
        Triple("James Boateng", "Thanks for sharing!", "Mon")
    )
    Column(Modifier.fillMaxSize()) {
        BrandHeader("Private conversations")
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Messages", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = {}) { Icon(Icons.Default.Edit, "New message", tint = Blue) }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats) { chat ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).clickable { }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(chat.first.take(1), Blue)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(chat.first, fontWeight = FontWeight.Bold)
                        Text(chat.second, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                    }
                    Text(chat.third, color = Muted, fontSize = 10.sp)
                }
            }
        }
        Text("Demo inbox: messages are not sent or stored online yet.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(16.dp))
    }
}

@Composable
private fun ProfileScreen() {
    Column(Modifier.fillMaxSize()) {
        BrandHeader("Your creator space")
        Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(22.dp)).background(Panel).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(90.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue))), contentAlignment = Alignment.Center) {
                Text("R", fontSize = 42.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(10.dp))
            Text("Your Retro Profile", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("@yourusername", color = Blue)
            Text("Your world. Your people. Your story.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("0", "Posts"); Stat("0", "Followers"); Stat("0", "Following")
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = {}) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(6.dp)); Text("Edit profile") }
        }
        listOf("Saved posts", "Creator tools", "Notifications", "Settings & privacy", "Help & safety").forEach { label ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(12.dp)).background(Panel).clickable { }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ChevronRight, null, tint = Blue)
                Spacer(Modifier.width(8.dp))
                Text(label, Modifier.weight(1f))
                Icon(Icons.Default.ArrowForwardIos, null, tint = Muted, modifier = Modifier.size(14.dp))
            }
        }
    }
}

@Composable
private fun Stat(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(number, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 12.sp)
    }
}
